﻿
app.controller("OrchestratorQueue", function ($scope, $http) {

    $scope.model = {};
    $scope.Values = {};
    $scope.check = {};
    $scope.model.Process = [];
    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.cancel = function () {
        $('input[type=text]').each(function (i, item) {
            $(item).val('');
            $('#check' + i).attr("checked", false);
            $('#txtProcess' + (i + 1)).attr("disabled", "disabled");

        });
        $scope.loanNumber = '';
    };

    $scope.clearText = function (index) {
        $('input[type=text]').each(function (i, item) {
            if (i === index) {
                $(item).val('');
                $('#check' + i).attr("checked", false);
                $('#txtProcess' + (index + 1)).attr("disabled", "disabled");
            }
        });

    };
    $scope.apply = function () {
        
        var boxes = $(":checkbox:checked");
        if (boxes.length <= 0) {
            SetMessage('Min');
        }
        else {
            $('input[type=text]').each(function (i, item) {
                if ($('#check' + i).is(':checked')) {
                    $(item).val($scope.loanNumber);
                }
            });
        }
    };

    $scope.checkCount = function (e, index) {
        var boxes = $(":checkbox:checked");
        if (boxes.length > 3) {
            e.preventDefault();
            e.stopPropagation();
            SetMessage('Max');
        }
        else {
            if ($('#check' + (index - 1)).is(":not(:checked)")) {
                $('#txtProcess' + index).val('');
                $('#txtProcess' + index).attr("disabled", "disabled");
            }
            else {
                $('#txtProcess' + index).removeAttr("disabled");
            }

        }

    };

    $scope.GetDetails = function () {
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: 'GetProcess',
        }).then(function (response) {
            returnedData = JSON.parse(response.data);
            $scope.model.Process = [];
            if (returnedData.length > 0) {
                $.each(returnedData, function (index, item) {
                    $scope.model.Process.push(item.Value);
                });
            }
            $scope.HideLoaderImg();
        }, function errorCallback(response) {

        });
    }


    $scope.CheckRobotBusy = function () {
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: 'GetJobs',
        }).then(function (response) {
            var count=parseInt(response.data);
            debugger;
            if (count > 0)
            {
               
                SetMessage('Busy'); 
            }
            else
            {
                $scope.confirmationDialog();
            }
            $scope.HideLoaderImg();
        }, function errorCallback(response) {
            SetMessage('Error');
        });
    }

    $scope.confirmSubmit = function () {
        isValid = true;
        var boxes = $(":checkbox:checked");
        $('input[type=text]').each(function (i, item) {
            if ($('#check' + i).is(':checked') && $('#txtProcess' + (i + 1)).val() == '') {
                isValid = false;
            }
        });
        if (boxes.length <= 0) {
            SetMessage('Min');
        }
        else if (isValid == false) {
            SetMessage('Empty');
        }
        else {
            //$scope.confirmationDialog();
            $scope.CheckRobotBusy();
        }

    };


    $scope.prepareConfirmSubmit = function (e) {
        
        $scope.confirmDetails = [];
        if ($scope.model.Process.length > 0) {
            $('input[type=text]').each(function (i, item) {
                if ($('#check' + i).is(':checked')) {
                    var processText = $(item).val();
                    if (processText != null && processText != '' && processText != undefined) {
                        $scope.selected = {};
                        $scope.selected.ProcessName = $scope.model.Process[i].split(',')[0];
                        $scope.selected.ProcessTxt = processText;
                        $scope.confirmDetails.push($scope.selected);
                    }
                }
            });

        }

    };

    $scope.submit = function () {
        $scope.ShowLoaderImg();
        $scope.ListDetails = [];
        if ($scope.model.Process.length > 0) {
            $('input[type=text]').each(function (i, item) {
                if ($('#check' + i).is(':checked')) {
                    var processText = $(item).val();
                    if (processText != null && processText != '' && processText != undefined) {
                        $scope.Details = {};
                        $scope.Details.ProcessName = $scope.model.Process[i].split(',')[1];
                        $scope.Details.ProcessTxt = processText;
                        $scope.Details.ReferenceDateRequired = $scope.model.Process[i].split(',')[2];
                        $scope.ListDetails.push($scope.Details);
                    }
                }
            });

        }
        console.log($scope.ListDetails);
        $http({
            method: 'POST',
            url: 'SubmitData',
            data: $scope.ListDetails,
        }).then(function (response) {
            
            $scope.HideLoaderImg();
            $scope.model = {};

            $('input[type=text]').each(function (i, item) {
                $(item).val('');
                $('#check' + i).attr("checked", false);
                $('#txtProcess' + (i + 1)).attr("disabled", "disabled");
            });
            //SetMessage('Save');
            jQuery("#confirmation-dialog .modal").modal('hide');
        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            jQuery("#confirmation-dialog .modal").modal('hide');
            $('input[type=text]').each(function (i, item) {
                $(item).val('');
                $('#check' + i).attr("checked", false);
                $('#txtProcess' + (i + 1)).attr("disabled", "disabled");
            });
            //SetMessage('Save');
            jQuery("#confirmation-dialog .modal").modal('hide');
        });

    };

    $scope.confirmationDialogConfig = {};

    $scope.confirmationDialog = function () {
        $scope.confirmationDialogConfig = {
            title: "Confirmation",
            message: "Are you sure you want to submit?",
            buttons: [{
                label: "Submit",
                action: "submitQueue"
            }]
        };
        $scope.showDialog(true);
        $scope.prepareConfirmSubmit();
    };

    $scope.executeDialogAction = function (action) {
        if (typeof $scope[action] === "function") {
            $scope[action]();
        }
    };

    $scope.submitQueue = function () {
       // $scope.CheckRobotBusy();
        $scope.submit();
    };

    $scope.showDialog = function (flag) {
        jQuery("#confirmation-dialog .modal").modal(flag ? 'show' : 'hide');
    };

    $scope.validateApp = function () {
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: 'ValidateToken',
        }).then(function (response) {
            alert(response.data);
            $scope.HideLoaderImg();
        }, function errorCallback(response) {

        });
    }


});
