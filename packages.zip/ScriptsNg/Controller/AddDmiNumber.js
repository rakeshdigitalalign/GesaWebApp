﻿
app.controller("AddDmiNumberController", function ($scope, $http) {
    $scope.AvailableDmiNumber = 0;
    $scope.model = {};
    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }


    $scope.ClearAll = function (e) {
        $scope.model.DmiNumber = "";
       
    }

   

    $scope.confirmSubmit = function () {
        if ($scope.validator.validate()) {
            $scope.data = {};
            $scope.data.DmiNumber = $scope.model.DmiNumber;
            var warnText = "Are you sure you want to submit this records?";
            $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
                if (confirmed) {
                    $scope.ShowLoaderImg();
                    $http({
                        method: 'POST',
                        url: 'SubmitDmiNumber',
                        data: $scope.data
                    }).then(function (response) {
                        debugger;
                        $scope.HideLoaderImg();
                        $scope.ClearAll();
                        SetMessage('Update');
                        $scope.getAvailableDmiNumber();
                    }, function errorCallback(response) {
                        $scope.HideLoaderImg();
                        SetMessage('Error');

                    });
                }
            });
        }

    }


    $scope.getAvailableDmiNumber = function () {
       
                    $scope.ShowLoaderImg();
                    $http({
                        method: 'Get',
                        url: 'GetAvailableDmiNumber',
                    }).then(function (response) {
                        $scope.AvailableDmiNumber = response.data;
                        debugger;
                        $scope.HideLoaderImg();
                       // $scope.ClearAll();
                       // SetMessage('Update');



                    }, function errorCallback(response) {
                        $scope.HideLoaderImg();
                        SetMessage('Error');

                    });
                }
           

});



