﻿
app.controller("OrchestratorQueueHistory", function ($scope, $http) {
    var baseUrl = "http://localhost:61603/";
 
    $scope.mainGridOptions = {  
        dataSource: {  
            type: "json",     
            transport: {                            
                 read: {  
                     url: baseUrl+"OrchestratorQueue/GetLoanNumbers",
                    dataType: "json",  
                } ,  
                 parameterMap: function (options, operation) {
                     debugger;
                     var opt = {};
                     opt = options;

                     return opt;
                 },
            },  
            schema: 
                    {  
                         model:  
                         {  
                             id: "ID",  
                             fields: {  
                                 ID: { editable: false, nullable: false, type: "number" },  
                                 LoanNumber: { editable: false, nullable: true, type: "string" }
                                 
                             }  
                         }  
                     },  
             
            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },  
        
        sortable: {  
            mode: "single",  
            allowUnsort:true  
        },          
        
        
        pageable: { pageSize:20, refresh: true },

        resizeable: true,       
        scrollable: false,
        dataBound: function () {  
            this.expandRow(this.tbody.find("tr.k-master-row").first());  
        },  
        //specify columns that you want to display   
        columns: [
        {  
            field: "LoanNumber",  
            title: "Loan Number",  
            width: "100px"  
        },
         {
             field: "HippoNumber",
             title: "Hippo Number",
             width: "100px"
         },
          {
              field: "MLO",
              title: "MLO",
              width: "100px"
          },
        
        ]  
    };  
    $scope.subgridOptions = function (dataItem) {  
        return {  
            dataSource: {  
                type: "json",  
                transport: {  
                    read: {                      
                        url: baseUrl + "OrchestratorQueue/GetLoanDetails",                       
                        dataType:"json"  
                    },
                    parameterMap: function (options, operation) {
                        debugger;
                    var opt = {};
                    opt = options;
                    opt.LoanID = dataItem.ID;                   
                    return opt;
                },
                },  
               
            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',
                
            }

            },  
            scrollable: false,  
            sortable: true,  
            pageable: { pageSize:20,refresh: true },
            columns: [             
            {  
                field: "ParentProcess",  
                title: "Parent Process",  
                width: "80px"  
            },
              {
                  field: "ChildProcess",
                  title: "Child Process",
                  width: "80px"
              },
           {
               field: "Success",
               title: "Success",
               width: "40px"
           },
           {
               field: "Reason",
               title: "Reason",
               width: "80px"
           },
           {
               field: "Comments",
               title: "Comments",
               width: "80px"
           },
              {
                  field: "RequestedBy",
                  title: "Requester",
                  width: "80px"
              },
            ]  
        };  
    };  
});  



  