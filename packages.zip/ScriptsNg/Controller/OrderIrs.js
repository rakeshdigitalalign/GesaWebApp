﻿
app.controller("OrderIrsController", function ($scope, $http) {
    $scope.model = {};
    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

  
    $scope.ClearAll=function(e)
    {
        $scope.model.LoanNumber = "";    
         $scope.model.Years="";
    }

    $scope.CheckRobotBusy = function () {
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: 'GetJobs',
        }).then(function (response) {
            var count = parseInt(response.data);
            debugger;
            $scope.HideLoaderImg();
            if (count > 0) {

                SetMessage('Busy');
            }
            else {
                $scope.confirmSubmit();
            }
            $scope.HideLoaderImg();
        }, function errorCallback(response) {
            SetMessage('Error');
        });
    }


    $scope.confirmSubmit = function () {
        if ($scope.validator.validate()) {
            $scope.data={};
            $scope.data.LoanNumber = $scope.model.LoanNumber;
            $scope.data.Years = $scope.model.Years;
            var warnText = "Are you sure you want to submit this records?";
            $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
                if (confirmed) {
                    $scope.ShowLoaderImg();
                    $http({
                        method: 'POST',
                        url: 'SubmitIrsData',                      
                        data: $scope.data
                    }).then(function (response) {
                        debugger;
                        $scope.HideLoaderImg();
                        $scope.ClearAll();
                        SetMessage('Update');



                    }, function errorCallback(response) {
                        $scope.HideLoaderImg();
                        SetMessage('Error');

                    });
                }
            });
        }

    }

});



